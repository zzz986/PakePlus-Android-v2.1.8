local activity=activity or this or service
local pkgName=activity.getPackageName()
local _check=(function()
  if "net.fusionapp"==pkgName then
    return true
  end
  return false
end)()
local _os_exit=os.exit
local _bindClas=luajava.bindClass
local _System=_bindClas("java.lang.System")
if _ENV==nil then _ENV={} end
_ENV["System"]=nil
local _M={
  ["exit"]=function(...)
    if _check then
      activity.finish()
     else
      return _System.exit(...)
    end
  end
}
setmetatable(_M,{
  ["__index"]=function(_M,method,...)
    local ok,arg=pcall(function()return _System.getField(method)end)
    if ok then
      _M[method]= arg.get(nil)--System没有实例化
     else
      _M[method]=function(...)
      local arg=_System[method](...)
      return _M
      end
    end
    return _M[method]
  end
})
_ENV["System"]=_M
os.exit=function(...)
  if _check then
      activity.finish()
     else
      return _os_exit(...)
    end
end


