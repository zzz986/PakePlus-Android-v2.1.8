弹出消息=print

function 获取浏览页(n)
  if n then
    return activity.uiManager.getPage(n)
   else
    return activity.uiManager.currentPage
  end
end

function 设置进度条颜色(color)
  this.uiManager.currentPage.webIndicator.color=color
end

function 获取浏览器()
  return 获取浏览页().webView
end

function 进入子页面(name,param)
  if(param~=nil)then
    activity.newActivity(name,param)
   else
    activity.newActivity(name)
  end
end


function 加载Js(str,callback)
  if not pcall(function()
      获取浏览器().evaluateJavascript(str,callback or function() end)
    end) then
    获取浏览器().loadUrl("javascript:"..str)
  end
end
--示例代码见监听浏览器事件

function 加载网页(url)
  获取浏览器().loadUrl(url)
end
--加载网页("https://wap.sogou.com/")

function 停止加载()
  获取浏览器().stopLoading()
end
--停止加载()

function 刷新网页()
  获取浏览器().reload()
end
--刷新网页()

function 网页前进()
  获取浏览器().goForward()
end
--网页前进()

function 网页后退()
  获取浏览器().goBack()
end
--网页后退()

function 返回网页顶部()
  获取浏览器().scrollTo(0,0)
end
--返回网页顶部()

function 退出页面()
  activity.finish()
end
function 退出程序()
  if activity.packageName == "net.fusionapp" then
    activity.finish()
  else
    System.exit(0)
  end
end
function 点击元素(Class名, 索引)
  if 索引 then
    加载Js("var element=document.getElementsByClassName(" .. Class名 .. ")[" .. 索引 .. "] if(typeof(element.onclick)=='undefined'){element.click()}else{element.onclick()}")
  else
    加载Js("var element=document.getElementsByClassName(" .. Class名 .. ")[0] if(typeof(element.onclick)=='undefined'){element.click()}else{element.onclick()}")
  end
end
function 返回网页顶部()
  加载Js("scrollTo(0,0)")
end
function 页内查找(str)
  获取浏览器().findAll(str)
end
function 获取当前UA()
  return 获取浏览器().getSettings().getUserAgentString()
end
function 执行Shell(code)
  os.execute(code)
end
function 清除浏览历史()
  获取浏览器().clearHistory()
end
function 获取网址()
  return 获取浏览器().getUrl()
end
local File=luajava.bindClass("java.io.File")
local Uri=luajava.bindClass("android.net.Uri")
local Intent=luajava.bindClass("android.content.Intent")
local xFileProvider=luajava.bindClass("androidx.core.content.FileProvider")
local Build=luajava.bindClass("android.os.Build")

function 安装APK(filePath)
  local intent = Intent(Intent.ACTION_VIEW);
  intent.addCategory("android.intent.category.DEFAULT");
  intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
  local uri = nil
  if (Build.VERSION.SDK_INT >=  24) then--24是N
    uri = xFileProvider.getUriForFile(activity, activity.getPackageName()..".FileProvider", File(filePath))
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
   else
    uri = Uri.fromFile(File(filePath))
  end
  intent.setDataAndType(uri, "application/vnd.android.package-archive");
  activity.startActivity(intent);
end
function 联系QQ(qqNUM)
  local s = "mqqwpa://im/chat?chat_type=wpa&uin=" .. qqNUM
  activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s)))
end
function 加QQ群(qqNUM)
  local s = "mqqapi://card/show_pslcard?src_type=internal&version=1&uin=" .. qqNUM .. "&card_type=group&source=qrcode"
  activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(s)))
end
function 写入文本(path, str)
  File(path).parentFile.mkdirs()
  io.open(path, "w"):write(str):close()
end
function 读取文本(path)
  if File(path).isFile() then
    return (io.open(path):read("*a"))
  end
end

function 设置标题(title)
  activity.uiManager.toolbar.titleText=title
end

function 设置子标题(title)
  activity.uiManager.toolbar.subtitleText=title
end



--复制("文本")

function 分享文本(text)
  local ShareCompat=luajava.bindClass "androidx.core.app.ShareCompat"
  ShareCompat.IntentBuilder
  .from(activity)
  .setText(text)
  .setType("text/plain")
  .startChooser()
end

function 获取剪切板()
  if(Context==nil)then
    import "android.content.Context"
  end
  return activity.getSystemService(Context.CLIPBOARD_SERVICE).getText()
end

function 复制文本(a)
  if(Context==nil)then
    import "android.content.Context"
  end
  activity.getSystemService(Context.CLIPBOARD_SERVICE).setText(a)
end


function 分享链接()
  分享文本(获取浏览器().url)
end

function 发送邮件(email,subject,content)
  import "android.content.Intent"
  i = Intent(Intent.ACTION_SEND)
  i.setType("message/rfc822")
  i.putExtra(Intent.EXTRA_EMAIL, {email})
  i.putExtra(Intent.EXTRA_SUBJECT,subject)
  i.putExtra(Intent.EXTRA_TEXT,content)
  activity.startActivity(Intent.createChooser(i, "Choice"))
end


local bindClass=luajava.bindClass
local AlertDialog=bindClass("android.app.AlertDialog")
local Builder=AlertDialog.Builder
local indexBuilderPool={}
function 对话框(ctx)
  local index=#indexBuilderPool+1
  local dialog=AlertDialog.Builder(ctx or activity or this)
  indexBuilderPool[index]=dialog
  local _M
  _M= {
    ["设置标题"]=function(...) dialog.setTitle(...) return _M end;
    ["设置消息"]=function(...) dialog.setMessage(...) return _M end;
    ["设置积极按钮"]=function(...)
      local args={...}
      if (#args==1) then
        dialog.setPositiveButton(args[1],nil)
       else
        dialog.setPositiveButton(...)
      end
      return _M end;
    ["设置消极按钮"]=function(...)
      local args={...}
      if (#args==1) then
        dialog.setNegativeButton(args[1],nil)
       else
        dialog.setNegativeButton(...)
      end
      return _M end;
    ["设置中立按钮"]=function(...)
      local args={...}
      if (#args==1) then
        dialog.setNeutralButton(args[1],nil)
       else
        dialog.setNeutralButton(...)
      end
      return _M end;
    ["显示"]=function(...)
      dialog=dialog.show(...)
      indexBuilderPool[index]=dialog
      return _M end;
    ["创建"]=function(...)
      dialog=dialog.create(...)
      indexBuilderPool[index]=dialog
      return _M end;
    ["取消"]=function(...) dialog.cancel(...) return _M end;
    ["关闭"]=function(...)
      dialog.dismiss(...)
      luajava.clear(indexBuilderPool[index])
      indexBuilderPool[index]=true
      return _M end;
    ["dismiss"]=function(...)
      dialog.dismiss(...)
      luajava.clear(indexBuilderPool[index])
      indexBuilderPool[index]=true
      return _M end;
    ["隐藏"]=function(...) dialog.hide(...) return _M end;
    ["设置按钮"]=function(...) dialog.setButton(...) return _M end;
    ["设置按钮1"]=function(...) dialog.setButton(...) return _M end;
    ["设置按钮2"]=function(...) dialog.setButton(...) return _M end;
    ["设置按钮3"]=function(...) dialog.setButton(...) return _M end;
    ["设置视图"]=function(...) dialog.setView(...) return _M end;
    ["设置图标"]=function(...) dialog.setIcon(...) return _M end;
    ["设置是否可以取消"]=function(...) dialog.setCancelable(...) return _M end;
    ["设置项目"]=function(...) dialog.setItems(...) return _M end;
    ["设置多选项目"]=function(...) dialog.setMultiChoiceItems(...) return _M end;
    ["设置取消监听器"]=function(...) dialog.setOnCancelListener(...) return _M end;
    ["设置关闭监听器"]=function(...) dialog.setOnDismissListener(...) return _M end;
    ["设置按键监听器"]=function(...) dialog.setOnKeyListener(...) return _M end;
    ["设置项目选择监听器"]=function(...) dialog.setOnItemSelectedListener(...) return _M end;
    ["启用测量时设置回收"]=function(...) dialog.setRecycleOnMeasureEnabled(...) return _M end;
    ["设置简单选择项目"]=function(...) dialog.setSingleChoiceItems(...) return _M end;
    ["设置自定义标题"]=function(...) dialog.setCustomTitle(...) return _M end;
    ["设置适配器"]=function(...) dialog.setAdapter(...) return _M end;
    ["设置光标"]=function(...) dialog.setCursor(...) return _M end;
    ["设置图标属性"]=function(...) dialog.setIconAttribute(...) return _M end;
    ["设置背景强制反向"]=function(...) dialog.setInverseBackgroundForced(...) return _M end;
    ["获得按钮"]=function(...) dialog.getButton(...) return _M end;
    ["获得列表视图"]=function(...) dialog.getListView(...) return _M end;
    ["当键按下时"]=function(...) dialog.onKeyDown(...) return _M end;
    ["当键抬起时"]=function(...) dialog.onKeyUp(...) return _M end;
    ["添加内容视图"]=function(...) dialog.addContentView(...) return _M end;
    ["设置内容视图"]=function(...) dialog.setContentView(...) return _M end;
    ["关闭选项菜单"]=function(...) dialog.closeOptionsMenu(...) return _M end;
    ["是否正在显示"]=function(...) dialog.isShowing(...) return _M end;
    ["获得窗口"]=function(...) dialog.getWindow(...) return _M end;
    ["设置能否在点击外部后取消"]=function(...) dialog.setCanceledOnTouchOutside(...) return _M end;
    ["设置取消消息"]=function(...) dialog.setCancelMessage(...) return _M end;
  }
  setmetatable(_M,{
    ["__index"]=function(_M,method,...)
      _M[method]=function(...)
        local ok,arg=pcall(function()return _System.getField(method)end)
        if ok then
          _M[method]= arg.get(dialog)
         else
          dialog[method](...)
        end
        return _M
      end
      return _M[method]
    end
  })
  return _M
end
function 泡沫对话框(ctxOrnum,num)
  if num==nil then
    num=ctxOrnum
    ctxOrnum=nil
  end
  local token="|"..tostring(tointeger(num))
  local OneTimeDialogMark=activity.getSharedData("ONE-TIME-DIALOG-MARK")
  if OneTimeDialogMark==nil then
    OneTimeDialogMark="|"
    activity.setSharedData("ONE-TIME-DIALOG-MARK",OneTimeDialogMark)
  end
  if OneTimeDialogMark:find(token,0,true) then
    local _M={}
    setmetatable(_M,{
      ["__index"]=function(_M,method,...)
        _M[method]=function(...) return _M end
        return _M[method]
      end
    })
    return _M
  end
  OneTimeDialogMark=OneTimeDialogMark..token
  local basedialog=对话框(ctxOrnum)
  local func1=basedialog["显示"]
  local func2=basedialog["show"]
  basedialog["显示"]=function(...)
    func1(...)
    activity.setSharedData("ONE-TIME-DIALOG-MARK",OneTimeDialogMark)
  end
  basedialog["show"]=function(...)
    func2(...)
    activity.setSharedData("ONE-TIME-DIALOG-MARK",OneTimeDialogMark)
  end
  return basedialog
end





